from decimal import Decimal
from pydantic import BaseModel


class ListedProductModel(BaseModel):
    id: int
    description: str
    price: Decimal
    stock: Decimal
