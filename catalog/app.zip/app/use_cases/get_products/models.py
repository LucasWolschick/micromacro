from decimal import Decimal
from pydantic import BaseModel


class GetProductResponse(BaseModel):
    id: int
    description: str
    price: Decimal
    stock: Decimal
