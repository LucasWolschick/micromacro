from decimal import Decimal
from pydantic import BaseModel


class AddProductRequest(BaseModel):
    description: str
    price: Decimal
    stock: Decimal = Decimal("0")

class AddProductResponse(BaseModel):
    id: int
    description: str
    price: Decimal
    stock: Decimal