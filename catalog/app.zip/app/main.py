import logging
from typing import Annotated, Awaitable, Callable
from fastapi import Depends, FastAPI, Request, Response
from fastapi.concurrency import asynccontextmanager
from fastapi.responses import JSONResponse

from app.use_cases.list_products import ListedProductModel, ListProducts
from app.use_cases.add_product import AddProductRequest, AddProductResponse, AddProduct
from app.use_cases.get_products import GetProductResponse, GetProduct

from app.db.connection import ConnectionPool
from app.db.deps import set_db_instance
from app.exceptions import ApplicationException, NotFoundException

db = ConnectionPool("catalog_db")
set_db_instance(db)

logging.basicConfig(level=logging.INFO)


@asynccontextmanager
async def lifespan(app: FastAPI):
    await db.connect()
    yield
    await db.disconnect()


app = FastAPI(lifespan=lifespan)


@app.middleware("http")
async def handle_exceptions(
    request: Request, call_next: Callable[[Request], Awaitable[Response]]
) -> Response:
    try:
        return await call_next(request)
    except NotFoundException as e:
        return JSONResponse(status_code=404, content={"message": str(e)})
    except ApplicationException as e:
        return JSONResponse(status_code=400, content={"message": str(e)})


@app.post("/product")
async def add_product(
    req: AddProductRequest, add_product: Annotated[AddProduct, Depends()]
) -> AddProductResponse:
    return await add_product.run(req)


@app.get("/product/{id}")
async def get_product(
    id: int,
    get_product: Annotated[GetProduct, Depends()],
) -> GetProductResponse:
    return await get_product.run(id)


@app.get("/product")
async def list_products(
    list_products: Annotated[ListProducts, Depends()],
) -> list[ListedProductModel]:
    return await list_products.run()
