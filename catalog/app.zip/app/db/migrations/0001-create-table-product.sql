CREATE TABLE product (
    id SERIAL PRIMARY KEY NOT NULL,
    description VARCHAR(1000) NOT NULL,
    price NUMERIC NOT NULL,
    stock NUMERIC NOT NULL
);